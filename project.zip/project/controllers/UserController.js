const userModel = require("../models/UserModel");
const jwt = require("jsonwebtoken");
const register = async (req, res) => {
  const user = req.body;
  const finduser = await userModel.findOne({
    email: user.email,
    phone: user.phone,
  });
  if (finduser) {
    return res.send("user already exist");
  }
  const newUser = new userModel(req.body);
  try {
    const newsave = await newUser.save();

    if (newsave) {
      return res.send("user registred sucessfully");
    }
  } catch (e) {
    return res.send("something went bad at server ");
  }
};

const login = async (req, res) => {
  try {
    const UserFind = await userModel.findOne({ email: req.body.email });

    if (UserFind) {
      if (UserFind.password === req.body.password) {
        const newTok = {
          id: UserFind._id,
          name: UserFind.name,
          email: UserFind.email,
          phone: UserFind.phone,
        };
        const token = jwt.sign(newTok, process.env.SECRET_KEY);

        return res.render("dashboard", { token });
      }
      return res.status(200).json({ error: "invalid login details" });
    }
    return res.status(200).json({ error: "invalid login details" });
  } catch {
    return res.status(500).json({ error: "something went bad at server" });
  }
};

module.exports = { register, login };
