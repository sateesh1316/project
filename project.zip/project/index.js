require("dotenv").config();
const express = require("express");
const path = require("path");
const app = express();

//database
require("./db/conn");

//require middle ware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//import routes

const userRoutes = require("./routes/UserRoutes");

app.use("/user", userRoutes);

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log(`app running on port http://localhost:${port}`);
});
