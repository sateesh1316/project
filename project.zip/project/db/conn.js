const mongoose = require("mongoose");

mongoose
  .connect(process.env.MONGODB_URI)
  .then((data) => {
    console.log("database connected and working fine");
  })
  .catch(() => {
    console.log("connection to database failed ");
  });
